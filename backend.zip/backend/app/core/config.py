from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # Explicit environment variable names via `alias`
    db_url: str = Field(alias="DB_URL")
    jwt_secret: str = Field(alias="JWT_SECRET")
    jwt_exp_minutes: int = 60   # default

    # Load from .env and ignore extra vars
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
