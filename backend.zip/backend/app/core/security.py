from datetime import datetime, timedelta
import jwt
from passlib.hash import bcrypt
from .config import settings

def hash_password(pw: str) -> str: return bcrypt.hash(pw)
def verify_password(pw: str, hashed: str) -> bool: return bcrypt.verify(pw, hashed)

def create_token(user_id: int):
    payload = {"sub": str(user_id),
               "exp": datetime.utcnow() + timedelta(minutes=settings.jwt_exp_minutes)}
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

def decode_token(token: str) -> int:
    return int(jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])["sub"])
