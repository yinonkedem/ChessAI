"""Central engine registry for the API.

Works both:
•  Locally on Windows  – expects engines/stockfish/stockfish.exe
•  Inside Docker/Linux – uses /usr/local/bin/stockfish (curl’d in Dockerfile)
"""
from __future__ import annotations

import pathlib
import random
from typing import Callable

import chess
from stockfish import Stockfish

# ------------------------------------------------------------------ #
# 1. Locate the Stockfish binary
# ------------------------------------------------------------------ #
LINUX_PATH   = pathlib.Path("/usr/games/stockfish")
WINDOWS_PATH = pathlib.Path(__file__).parent / "stockfish" / "stockfish.exe"

ENGINE_BIN = LINUX_PATH if LINUX_PATH.exists() else WINDOWS_PATH
if not ENGINE_BIN.exists():
    raise RuntimeError(
        f"Stockfish binary not found at {ENGINE_BIN}. "
        "Download it in Dockerfile or place stockfish.exe under engines/stockfish/."
    )

# ------------------------------------------------------------------ #
# 2. Concrete engine wrappers
# ------------------------------------------------------------------ #
def stockfish_best(fen: str, depth: int = 15) -> str:
    sf = Stockfish(
        path=str(ENGINE_BIN),
        depth=depth,
        parameters={"Threads": 2, "Hash": 128},
    )
    sf.set_fen_position(fen)
    return sf.get_best_move()


def random_best(fen: str, depth: int | None = None) -> str:
    board = chess.Board(fen)
    return random.choice(list(board.legal_moves)).uci()


# ------------------------------------------------------------------ #
# 3. Registry – add future agents here
# ------------------------------------------------------------------ #
ENGINE_REGISTRY: dict[str, Callable[[str, int], str]] = {
    "stockfish": stockfish_best,
    "random":    random_best,
}
