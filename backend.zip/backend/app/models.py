from datetime import datetime
from typing import Optional

from sqlmodel import SQLModel, Field as SQLField      # for DB tables
from pydantic import BaseModel, Field                 # for request/response

# ---------- plain request / response schemas ----------

class FENRequest(BaseModel):
    fen: str = Field(
        ...,
        examples=["rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"],
        description="FEN string",
    )

class BestMoveRequest(FENRequest):
    depth: int = Field(
        15, ge=1, le=30,
        description="Search depth for Stockfish"
    )

# ---------- database tables ----------

class User(SQLModel, table=True):
    id: Optional[int] = SQLField(default=None, primary_key=True)
    username: str = SQLField(index=True, unique=True)
    email: str    = SQLField(index=True, unique=True)
    password_hash: str
    created_at: datetime = SQLField(default_factory=datetime.utcnow)

class TrainingSample(SQLModel, table=True):
    id: Optional[int] = SQLField(default=None, primary_key=True)
    fen: str
    move: str
    result: int                      # 1 win / 0 draw / -1 loss
    owner_id: int | None = SQLField(foreign_key="user.id")
    ts: datetime = SQLField(default_factory=datetime.utcnow)
