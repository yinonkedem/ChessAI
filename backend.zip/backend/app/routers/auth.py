from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select
from ..db import get_session
from ..models import User
from ..core.security import hash_password, verify_password, create_token

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/signup")
def signup(username: str, email: str, password: str,
           session: Session = Depends(get_session)):
    if session.exec(select(User).where(User.username == username)).first():
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Username taken")
    user = User(username=username, email=email,
                password_hash=hash_password(password))
    session.add(user)
    session.commit()
    session.refresh(user)
    return {"token": create_token(user.id)}

@router.post("/login")
def login(username: str, password: str,
          session: Session = Depends(get_session)):
    user = session.exec(select(User).where(User.username == username)).first()
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Bad credentials")
    return {"token": create_token(user.id)}
