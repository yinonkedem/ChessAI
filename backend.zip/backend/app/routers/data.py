from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session
from ..db import get_session
from ..models import TrainingSample
from ..core.security import decode_token

router = APIRouter(prefix="/data", tags=["data"])

def current_user(token: str = "") -> int:
    try:
        return decode_token(token)
    except Exception:
        raise HTTPException(401, "Invalid token")

@router.post("/sample")
def add_sample(sample: TrainingSample,
               user_id: int = Depends(current_user),
               session: Session = Depends(get_session)):
    sample.owner_id = user_id
    session.add(sample)
    session.commit()
    return {"ok": True}
